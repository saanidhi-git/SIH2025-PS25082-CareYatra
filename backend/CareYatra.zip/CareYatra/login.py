import os
import uuid
import random
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from captcha.image import ImageCaptcha

# ---------------- SETUP ----------------
DB_FILE = "doctors.db"
PHOTO_FOLDER = "photos"
CAPTCHA_FOLDER = "captchas"

os.makedirs(PHOTO_FOLDER, exist_ok=True)
os.makedirs(CAPTCHA_FOLDER, exist_ok=True)

# Captcha store
captcha_store = {}
CHAR_SET = "ABCDEFGHJKLMNPQRSTUVWXYZ2346789"


# ---------------- DATABASE ----------------
def init_db():
    """Initialize SQLite DB"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS doctors (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hpid TEXT UNIQUE,
                    username TEXT,
                    password TEXT,
                    photo TEXT
                )''')
    conn.commit()
    conn.close()


def add_doctor(hpid, username, password, photo_path):
    """Add a new doctor (sign up)"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()

    # Hash password
    hashed_pw = generate_password_hash(password)

    # Save photo with unique name
    photo_filename = f"{uuid.uuid4()}_{os.path.basename(photo_path)}"
    saved_path = os.path.join(PHOTO_FOLDER, photo_filename)
    os.rename(photo_path, saved_path)

    try:
        c.execute("INSERT INTO doctors (hpid, username, password, photo) VALUES (?, ?, ?, ?)",
                  (hpid, username, hashed_pw, photo_filename))
        conn.commit()
        print("✅ Doctor registered successfully!")
    except sqlite3.IntegrityError:
        print("❌ HPID already registered!")
    finally:
        conn.close()


def verify_doctor(hpid, password):
    """Check login credentials"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT id, username, password, photo FROM doctors WHERE hpid = ?", (hpid,))
    row = c.fetchone()
    conn.close()

    if not row:
        return False, "❌ HPID not found!"

    user_id, username, stored_pw, photo = row
    if check_password_hash(stored_pw, password):
        return True, f"✅ Welcome Dr. {username}!"
    else:
        return False, "❌ Incorrect password!"


# ---------------- CAPTCHA ----------------
def generate_image_captcha():
    captcha_text = ''.join(random.choices(CHAR_SET, k=4))
    captcha_id = str(uuid.uuid4())

    image = ImageCaptcha(width=200, height=80)
    filename = f"{CAPTCHA_FOLDER}/{captcha_id}.png"
    image.write(captcha_text, filename)

    captcha_store[captcha_id] = captcha_text
    return captcha_id, filename


def verify_captcha(captcha_id, user_input):
    correct_text = captcha_store.get(captcha_id)
    if not correct_text:
        return False, "Captcha not found or expired!"

    # One-time use
    del captcha_store[captcha_id]
    try:
        os.remove(f"{CAPTCHA_FOLDER}/{captcha_id}.png")
    except FileNotFoundError:
        pass

    if user_input.upper() == correct_text:
        return True, "✅ Captcha verified!"
    else:
        return False, f"❌ Incorrect! Correct was {correct_text}"


def generate_math_captcha():
    a, b = random.randint(1, 9), random.randint(1, 9)
    return f"{a} + {b}", a + b


# ---------------- MAIN TEST ----------------
if __name__ == "__main__":
    init_db()

    print("=== Doctor Portal Backend Test ===")
    print("1. Register doctor")
    print("2. Login doctor")
    choice = input("Enter choice: ")

    if choice == "1":
        hpid = input("Enter HPID: ")
        username = input("Enter Username: ")
        password = input("Enter Password: ")
        photo_path = input("Enter path of photo file: ")
        add_doctor(hpid, username, password, photo_path)

    elif choice == "2":
        hpid = input("Enter HPID: ")
        password = input("Enter Password: ")

        # Step 1: Captcha
        cid, file = generate_image_captcha()
        print(f"Captcha created: {file}")
        user_text = input("Enter captcha text (or type 'skip'): ")

        if user_text.lower() == "skip":
            q, ans = generate_math_captcha()
            print("Solve math captcha:", q)
            try:
                user_ans = int(input("Answer: "))
                if user_ans == ans:
                    print("✅ Captcha verified via math!")
                    ok, msg = verify_doctor(hpid, password)
                    print(msg)
                else:
                    print("❌ Wrong math captcha!")
            except ValueError:
                print("❌ Invalid input!")
        else:
            valid, msg = verify_captcha(cid, user_text)
            print(msg)
            if valid:
                ok, msg = verify_doctor(hpid, password)
                print(msg)
    else:
        print("❌ Invalid choice")
