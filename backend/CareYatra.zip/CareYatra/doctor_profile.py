# doctor_profile.py
import sqlite3

DB_NAME = "doctor.db"

def create_table():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    # 🔥 Always reset table so columns match our program
    c.execute("DROP TABLE IF EXISTS profiles")
    c.execute('''CREATE TABLE profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    full_name TEXT,
                    dob TEXT,
                    speciality TEXT,
                    hospital TEXT,
                    email TEXT
                )''')
    conn.commit()
    conn.close()

def add_profile():
    print("\n--- Add Doctor Profile ---")
    full_name = input("Full Name: ")
    dob = input("Birthdate (YYYY-MM-DD): ")
    speciality = input("Speciality: ")
    hospital = input("Hospital Address (short): ")
    email = input("Email ID: ")

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO profiles (full_name, dob, speciality, hospital, email) VALUES (?, ?, ?, ?, ?)",
              (full_name, dob, speciality, hospital, email))
    conn.commit()
    conn.close()
    print("✅ Profile added successfully!")

def view_profiles():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM profiles")
    rows = c.fetchall()
    conn.close()

    if rows:
        print("\n--- Saved Doctor Profiles ---")
        for row in rows:
            print(f"[ID: {row[0]}] {row[1]}, DOB: {row[2]}, Speciality: {row[3]}, "
                  f"Hospital: {row[4]}, Email: {row[5]}")
    else:
        print("\n⚠️ No profiles found.")

def edit_profile():
    view_profiles()
    profile_id = input("\nEnter the ID of the profile to edit: ")

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM profiles WHERE id=?", (profile_id,))
    profile = c.fetchone()

    if profile:
        print("\n--- Editing Profile ---")
        full_name = input(f"Full Name [{profile[1]}]: ") or profile[1]
        dob = input(f"Birthdate [{profile[2]}]: ") or profile[2]
        speciality = input(f"Speciality [{profile[3]}]: ") or profile[3]
        hospital = input(f"Hospital [{profile[4]}]: ") or profile[4]
        email = input(f"Email [{profile[5]}]: ") or profile[5]

        c.execute("""UPDATE profiles 
                     SET full_name=?, dob=?, speciality=?, hospital=?, email=? 
                     WHERE id=?""",
                  (full_name, dob, speciality, hospital, email, profile_id))
        conn.commit()
        print("✅ Profile updated successfully!")
    else:
        print("⚠️ Profile not found.")
    conn.close()

def delete_profile():
    view_profiles()
    profile_id = input("\nEnter the ID of the profile to delete: ")

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("DELETE FROM profiles WHERE id=?", (profile_id,))
    conn.commit()
    conn.close()
    print("🗑️ Profile deleted successfully!")

def menu():
    while True:
        print("\n===== Enter Your Profile Details =====")
        print("1. Add Profile")
        print("2. View Profiles")
        print("3. Edit Profile")
        print("4. Delete Profile")
        print("5. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            add_profile()
        elif choice == "2":
            view_profiles()
        elif choice == "3":
            edit_profile()
        elif choice == "4":
            delete_profile()
        elif choice == "5":
            print("👋 Exiting... Bye!")
            break
        else:
            print("⚠️ Invalid choice, try again.")

if __name__ == "__main__":
    create_table()   # always creates fresh table with correct columns
    menu()
