from captcha.image import ImageCaptcha
import random, uuid, os

# Store captchas in memory {id: text}
captcha_store = {}

# Folder to save captcha images
os.makedirs("captchas", exist_ok=True)

# Character set (no confusing ones like O/0, I/1, 5/S)
CHAR_SET = "ABCDEFGHJKLMNPQRSTUVWXYZ2346789"

def generate_image_captcha():
    """Generate an image captcha"""
    captcha_text = ''.join(random.choices(CHAR_SET, k=4))
    captcha_id = str(uuid.uuid4())

    image = ImageCaptcha(width=200, height=80)
    filename = f"captchas/{captcha_id}.png"
    image.write(captcha_text, filename)

    captcha_store[captcha_id] = captcha_text
    return captcha_id, filename

def verify_captcha(captcha_id, user_input):
    """Verify user input for captcha"""
    correct_text = captcha_store.get(captcha_id)
    if not correct_text:
        return False, "Captcha not found or expired!"

    # One-time use
    del captcha_store[captcha_id]
    try:
        os.remove(f"captchas/{captcha_id}.png")
    except FileNotFoundError:
        pass

    if user_input.upper() == correct_text:
        return True, "✅ Captcha verified!"
    else:
        return False, f"❌ Incorrect! Correct was {correct_text}"

def generate_math_captcha():
    """Generate a simple math captcha"""
    a, b = random.randint(1, 9), random.randint(1, 9)
    return f"{a} + {b}", a + b

# ---------------- MAIN TEST -----------------
if __name__ == "__main__":
    cid, file = generate_image_captcha()
    print(f"Captcha created! Open the image: {file}")

    user_text = input("Enter captcha text (or type 'skip' if unreadable): ")

    if user_text.lower() == "skip":
        # Fallback to math captcha
        q, ans = generate_math_captcha()
        print("New Captcha:", q)
        try:
            user_ans = int(input("Your answer: "))
            if user_ans == ans:
                print("✅ Captcha verified via math challenge!")
            else:
                print(f"❌ Wrong! Correct answer was {ans}")
        except ValueError:
            print("❌ Invalid input!")
    else:
        # Normal image captcha verification
        status, msg = verify_captcha(cid, user_text)
        print(msg)
