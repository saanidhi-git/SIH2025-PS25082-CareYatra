import re
import sqlite3
import uuid
import os
import random
from werkzeug.security import generate_password_hash, check_password_hash
from captcha.image import ImageCaptcha



# ---------------- DATABASE SETUP ----------------
DB_NAME = "doctors.db"

def init_db(reset=False):
    """Initialize database. If reset=True, it will drop and recreate the table."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    if reset:
        c.execute("DROP TABLE IF EXISTS doctors")

    c.execute("""
        CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hpid TEXT UNIQUE NOT NULL,
            username TEXT NOT NULL,
            password_hash TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

# ---------------- HPID VALIDATION ----------------
HPID_PATTERN = re.compile(r"^HPID-[A-Z]{2,3}-[A-Z]{2,4}-\d{8,10}$")

def is_valid_hpid(hpid: str) -> bool:
    """Check if HPID matches the valid format."""
    return bool(HPID_PATTERN.match(hpid))

# ---------------- CAPTCHA UTILS ----------------
captcha_store = {}
os.makedirs("captchas", exist_ok=True)

CHAR_SET = "ABCDEFGHJKLMNPQRSTUVWXYZ2346789"

def generate_image_captcha():
    """Generate an image captcha"""
    captcha_text = ''.join(random.choices(CHAR_SET, k=4))
    captcha_id = str(uuid.uuid4())

    image = ImageCaptcha(width=200, height=80)
    filename = f"captchas/{captcha_id}.png"
    image.write(captcha_text, filename)

    captcha_store[captcha_id] = captcha_text
    return captcha_id, filename

def verify_captcha(captcha_id, user_input):
    """Verify user input for captcha"""
    correct_text = captcha_store.get(captcha_id)
    if not correct_text:
        return False, "Captcha not found or expired!"

    # Delete after one use
    del captcha_store[captcha_id]
    try:
        os.remove(f"captchas/{captcha_id}.png")
    except FileNotFoundError:
        pass

    if user_input.upper() == correct_text:
        return True, "✅ Captcha verified!"
    else:
        return False, f"❌ Incorrect! Correct was {correct_text}"

# ---------------- REGISTRATION ----------------
def add_doctor(hpid, username, password):
    """Register a new doctor"""
    if not is_valid_hpid(hpid):
        print("❌ Invalid HPID format! Example: HPID-IN-DR-0001234567")
        return

    password_hash = generate_password_hash(password)

    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("INSERT INTO doctors (hpid, username, password_hash) VALUES (?, ?, ?)",
                  (hpid, username, password_hash))
        conn.commit()
        conn.close()
        print("✅ Doctor registered successfully!")
    except sqlite3.IntegrityError:
        print("❌ HPID already registered!")

# ---------------- LOGIN ----------------
def login_doctor(hpid, password):
    """Login doctor with HPID, password, and captcha verification"""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT password_hash, username FROM doctors WHERE hpid = ?", (hpid,))
    row = c.fetchone()
    conn.close()

    if row:
        stored_hash, username = row

        # Step 1: Verify Password
        if not check_password_hash(stored_hash, password):
            print("❌ Wrong password!")
            return False

        # Step 2: Captcha challenge
        cid, file = generate_image_captcha()
        print(f"🔐 Captcha created! Open this image: {file}")
        user_text = input("Enter captcha text (or type 'skip'): ")

        if user_text.lower() == "skip":
            # Fallback to math captcha
            a, b = random.randint(1, 9), random.randint(1, 9)
            ans = a + b
            try:
                user_ans = int(input(f"Captcha challenge: {a} + {b} = "))
                if user_ans == ans:
                    print(f"✅ Login successful! Welcome, Dr. {username}")
                    return True
                else:
                    print(f"❌ Wrong math captcha! Correct answer was {ans}")
                    return False
            except ValueError:
                print("❌ Invalid input for captcha!")
                return False
        else:
            # Verify image captcha
            status, msg = verify_captcha(cid, user_text)
            print(msg)
            if status:
                print(f"✅ Login successful! Welcome, Dr. {username}")
                return True
                fill_profile(hpid)
            else:
                return False
    else:
        print("❌ HPID not found!")
        return False

# ---------------- MAIN ----------------
if __name__ == "__main__":
    init_db(reset=True)  # ⚠️ Set reset=True to rebuild DB each run (dev mode)

    while True:
        choice = input("\n1. Register\n2. Login\n3. Exit\nChoose: ")
        if choice == "1":
            hpid = input("Enter HPID: ").strip()
            username = input("Enter Username: ").strip()
            password = input("Enter Password: ").strip()
            add_doctor(hpid, username, password)
        elif choice == "2":
            hpid = input("Enter HPID: ").strip()
            password = input("Enter Password: ").strip()
            login_doctor(hpid, password)
        elif choice == "3":
            print("👋 Exiting...")
            break
        else:
            print("❌ Invalid choice!")
