import tkinter as tk
from tkinter import messagebox, filedialog
from tkinterdnd2 import TkinterDnD, DND_FILES
import pandas as pd
import matplotlib.pyplot as plt
import os

# =============== Functions =================
def load_file(file_path):
    try:
        if file_path.endswith(".csv"):
            df = pd.read_csv(file_path)
        elif file_path.endswith(".xlsx") or file_path.endswith(".xls"):
            df = pd.read_excel(file_path)
        else:
            messagebox.showerror("Invalid File", "Please drop a CSV or Excel file only!")
            return None
        return df
    except Exception as e:
        messagebox.showerror("Error", f"Failed to read file: {e}")
        return None

def on_drop(event):
    file_path = event.data.strip("{}")  # clean file path
    global df, file_name
    df = load_file(file_path)
    if df is not None:
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        messagebox.showinfo("Success", f"File '{file_name}' uploaded successfully!")
        plot_graphs()

def plot_graphs():
    if df is None:
        messagebox.showerror("No Data", "Upload a file first!")
        return
    
    # Ask user which column to plot
    column = df.columns[0]  # default: first column
    if df[column].dtype not in ['int64', 'float64']:
        messagebox.showerror("Error", "First column must be numeric for plotting!")
        return

    # Pie chart
    plt.figure()
    df[column].value_counts().plot.pie(autopct="%1.1f%%")
    plt.title(f"Pie Chart of {column}")
    plt.show()

    # Bar Graph
    plt.figure()
    df[column].value_counts().plot.bar()
    plt.title(f"Bar Graph of {column}")
    plt.ylabel("Count")
    plt.show()

def save_graphs():
    if df is None:
        messagebox.showerror("No Data", "Upload a file first!")
        return

    column = df.columns[0]
    save_path = filedialog.askdirectory(title="Select Folder to Save Graphs")
    if not save_path:
        return

    # Pie chart save
    plt.figure()
    df[column].value_counts().plot.pie(autopct="%1.1f%%")
    plt.title(f"Pie Chart of {column}")
    plt.savefig(os.path.join(save_path, f"{file_name}_pie.png"))

    # Bar chart save
    plt.figure()
    df[column].value_counts().plot.bar()
    plt.title(f"Bar Graph of {column}")
    plt.ylabel("Count")
    plt.savefig(os.path.join(save_path, f"{file_name}_bar.png"))

    messagebox.showinfo("Saved", f"Graphs saved in {save_path}")

# =============== Tkinter GUI =================
root = TkinterDnD.Tk()
root.title("File Upload & Plotter")
root.geometry("500x300")

df = None
file_name = ""

label = tk.Label(root, text="Drag & Drop your CSV/Excel file here", 
                 relief="solid", width=50, height=5)
label.pack(pady=20)

label.drop_target_register(DND_FILES)
label.dnd_bind("<<Drop>>", on_drop)

btn_frame = tk.Frame(root)
btn_frame.pack(pady=20)

plot_btn = tk.Button(btn_frame, text="Replot Graphs", command=plot_graphs)
plot_btn.grid(row=0, column=0, padx=10)

save_btn = tk.Button(btn_frame, text="Save Graphs", command=save_graphs)
save_btn.grid(row=0, column=1, padx=10)

root.mainloop()
